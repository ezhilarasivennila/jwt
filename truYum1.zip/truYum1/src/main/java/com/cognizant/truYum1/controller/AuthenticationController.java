package com.cognizant.truYum1.controller;

import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.springframework.security.crypto.codec.Base64;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import io.jsonwebtoken.JwtBuilder;

import io.jsonwebtoken.Jwts;

import io.jsonwebtoken.SignatureAlgorithm;
@RestController
public class AuthenticationController {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

	Map<String,String> authenticateMap=new HashMap<String, String>();
@GetMapping("/authenticate")
public Map<String,String> getauthenticate(@RequestHeader("Authorization") String authHeader)
{
	LOGGER.info("start");
	LOGGER.info(authHeader);
	String[] sp=authHeader.split(" ");
	AuthenticationController ac=new AuthenticationController();
	String kval=ac.getUser(sp[1]);
	LOGGER.info("Username and password: "+kval);
	String []coval=kval.split(":");
	LOGGER.info("Username: "+coval[0]);
	String tokval=ac.generateJwt(coval[0]);
	LOGGER.info("JWT token: "+tokval);
	LOGGER.info("End");
	authenticateMap.put("token", tokval);
	return authenticateMap;
}
private String getUser(String authHeader)
{
	byte[] byteval=Base64.getDecoder().decode(authHeader.getBytes());
	
	return new String(byteval);
}
private String generateJwt(String user)
{
	JwtBuilder builder = Jwts.builder();

	builder.setSubject(user);

	// Set the token issue time as current time

	builder.setIssuedAt(new Date());

	// Set the token expiry as 20 minutes from now

	builder.setExpiration(new Date((new Date()).getTime() + 1200000));

	builder.signWith(SignatureAlgorithm.HS256, "secretkey");

	String token = builder.compact();

	return token;
}
}
